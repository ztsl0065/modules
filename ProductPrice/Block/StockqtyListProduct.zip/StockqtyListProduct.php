<?php

namespace Zehntech\ProductPrice\Block;

class StockqtyListProduct extends \Magento\CatalogInventory\Block\Stockqty\AbstractStockqty
{
	public function getProduct()
	{
		return $this->product;
	}
	
	public function getAvailableQuantity($product)
	{

		// $this->product = $product;
		// // return $this->getStockQtyLeft();
		// print_r($product->getExtensionAttributes()->getStockItem()->getQty());
		// die();
		// return  12;
		// return $product->getExtensionAttributes()->getStockItem()->getQty();
		return $this->stockRegistry->getStockItem($product->getId())->getQty();

	}
}